from flask import Flask, render_template, request, redirect, session, flash
import sqlite3
import bcrypt
import re
import secrets

app = Flask(__name__)

# Secret Key
app.secret_key = secrets.token_hex(32)

# Secure Session Configuration
app.config.update(
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE="Lax"
)

DATABASE = "database.db"


# ============================================
# Create Database
# ============================================
def create_database():

    conn = sqlite3.connect(DATABASE)
    cursor = conn.cursor()

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS users(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL
        )
    """)

    conn.commit()
    conn.close()


create_database()


# ============================================
# Home
# ============================================
@app.route("/")
def home():
    return redirect("/login")


# ============================================
# Register
# ============================================
@app.route("/register", methods=["GET", "POST"])
def register():

    if request.method == "POST":

        username = request.form["username"].strip()
        password = request.form["password"]

        # Username Validation
        if len(username) < 4:
            flash("Username must contain at least 4 characters.")
            return redirect("/register")

        # Password Validation
        if len(password) < 8:
            flash("Password must contain at least 8 characters.")
            return redirect("/register")

        if not re.search(r"[A-Z]", password):
            flash("Password must contain at least one uppercase letter.")
            return redirect("/register")

        if not re.search(r"[a-z]", password):
            flash("Password must contain at least one lowercase letter.")
            return redirect("/register")

        if not re.search(r"[0-9]", password):
            flash("Password must contain at least one number.")
            return redirect("/register")

        if not re.search(r"[!@#$%^&*(),.?\":{}|<>]", password):
            flash("Password must contain at least one special character.")
            return redirect("/register")

        # Hash Password
        hashed_password = bcrypt.hashpw(
            password.encode("utf-8"),
            bcrypt.gensalt()
        )

        try:

            conn = sqlite3.connect(DATABASE)
            cursor = conn.cursor()

            cursor.execute(
                "INSERT INTO users(username,password) VALUES(?,?)",
                (username, hashed_password.decode("utf-8"))
            )

            conn.commit()
            conn.close()

            flash("Registration Successful. Please Login.")
            return redirect("/login")

        except sqlite3.IntegrityError:

            flash("Username already exists.")
            return redirect("/register")

    return render_template("register.html")


# ============================================
# Login
# ============================================
@app.route("/login", methods=["GET", "POST"])
def login():

    if request.method == "POST":

        username = request.form["username"].strip()
        password = request.form["password"]

        conn = sqlite3.connect(DATABASE)
        cursor = conn.cursor()

        cursor.execute(
            "SELECT password FROM users WHERE username=?",
            (username,)
        )

        user = cursor.fetchone()

        conn.close()

        if user:

            if bcrypt.checkpw(
                password.encode("utf-8"),
                user[0].encode("utf-8")
            ):

                session["username"] = username

                return redirect("/dashboard")

        flash("Invalid Username or Password")

    return render_template("login.html")


# ============================================
# Dashboard
# ============================================
@app.route("/dashboard")
def dashboard():

    if "username" not in session:
        return redirect("/login")

    return render_template(
        "dashboard.html",
        username=session["username"]
    )


# ============================================
# Logout
# ============================================
@app.route("/logout")
def logout():

    session.clear()

    flash("Logged out successfully.")

    return redirect("/login")


# ============================================
# Security Headers
# ============================================
@app.after_request
def add_security_headers(response):

    response.headers["Cache-Control"] = "no-store, no-cache, must-revalidate"
    response.headers["Pragma"] = "no-cache"
    response.headers["Expires"] = "0"

    return response


# ============================================
# Main
# ============================================
if __name__ == "__main__":
    app.run(debug=True)